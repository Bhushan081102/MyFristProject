package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieRentalSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieRentalSystemApplication.class, args);
	}

}
