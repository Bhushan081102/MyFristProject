package com.project.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Dao.MovieDao;
import com.project.Entity.Movie;

@Service
public class MovieService {

	@Autowired
	MovieDao dao;
	
	public List<Movie> getallMovies(){
		return dao.getallInfo();
		
	}
	
	public Movie addanothermovie(Movie movie) {
		return dao.addAnotherDetails(movie);
		
	}
	
	public Movie getInfoById(int Id) {
		return dao.getmoviebyId(Id);
	}
	
	public Movie getDataBytitle(String title) {
		return dao.getDetailByName(title);
		
	}
	
	public Movie UpdateMovieInfodetail(Movie movie) {
		return dao.UpdateMovieInfo(movie);
		
	}
	
	public Movie DeletedataById(int Id) {
		return dao.deleteDetailById(Id);
		
	}
}
