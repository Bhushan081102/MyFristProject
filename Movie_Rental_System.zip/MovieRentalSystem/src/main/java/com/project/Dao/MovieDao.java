package com.project.Dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.project.Entity.Movie;

@Configuration
public class MovieDao {
	
	@Autowired
	SessionFactory factory;
	
	public List<Movie> getallInfo(){
		Session session = factory.openSession();
		String hql = "FROM Movie";
        Query<Movie> query = session.createQuery(hql, Movie.class);
        List<Movie> movie=query.getResultList();
        return movie ;
	}
	
	public Movie getmoviebyId(int Id) {
		Session session=factory.openSession();
		Movie movie=session.load(Movie.class, Id);
		return movie;
	}
	
	public Movie getDetailByName(String title) {
		Session session=factory.openSession();
		String hql = "FROM Movie WHERE title = :title";
        Query<Movie> query = session.createQuery(hql, Movie.class);
        query.setParameter("title", title);
        Movie movie = query.uniqueResult();
		return movie;
		
	}
	public Movie addAnotherDetails(Movie movie) {
		Session session = factory.openSession();
		session.save(movie);
		session.beginTransaction().commit();
		return movie;
		
	}
	
	public Movie UpdateMovieInfo(Movie movie) {
		Session session = factory.openSession();
		session.update(movie);
		session.beginTransaction().commit();
		return movie;
		
	}
	
	public Movie deleteDetailById(int Id) {
		Session session=factory.openSession();
		Movie movie = session.get(Movie.class, Id);
        if (movie != null) {
            session.delete(movie);
        }
        session.beginTransaction().commit();
		return movie;
	}
}
