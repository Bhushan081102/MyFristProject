package com.project.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.Entity.Movie;
import com.project.Entity.UserLogin;
import com.project.Service.MovieService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class MovieController {

	@Autowired
	MovieService service;
	
	
	@GetMapping("getallmovies")
	public List<Movie> getallmovies(){
		return service.getallMovies();	
	}
	
	@PostMapping("addMovie")
	public Movie addAnotherInfo(@RequestBody Movie movie) {
		return service.addanothermovie(movie);
		
	}
	
	@GetMapping("getallmovies/{Id}")
	public Movie getDetialsById(@PathVariable("Id") int Id) {
		return service.getInfoById(Id);
		
	}
	
	@GetMapping("getmoviebyname/{title}")
	public Movie getDetailsByTitle(@PathVariable("title") String title) {
		return service.getDataBytitle(title);
		
	}
	
	@PutMapping("getallmovies/{Id}/UpdateInfo")
	public Movie updateAllInfo(@RequestBody Movie movie) {
		return service.UpdateMovieInfodetail(movie);
		
	}
	
	@DeleteMapping("deletemovie/{Id}")
	public Movie deleteDataBYId(@PathVariable("Id") int Id) {
		return service.DeletedataById(Id);
	}
	
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestBody UserLogin login) {
	    if (login.getUsername().equals("user") && login.getPassword().equals("password")) {
	        return ResponseEntity.ok("Login successful");
	    }
	    return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
	}
    
}
