package com.project.Entity;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
@JsonPropertyOrder({"id","title", "genre", "director", "releaseDate", "rating", "ticketprice"})
public class Movie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int Id;
	String title; 
	String genre;
	String director;
	int releaseDate;
	int rating;
	int ticketprice;
	
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public Movie(String title, String genre, String director, int releaseDate, int rating, int ticketprice) {
		super();
		this.title = title;
		this.genre = genre;
		this.director = director;
		this.releaseDate = releaseDate;
		this.rating = rating;
		this.ticketprice = ticketprice;
	}


	public Movie(int id, String title, String genre, String director, int releaseDate, int rating, int ticketprice) {
		super();
		Id = id;
		this.title = title;
		this.genre = genre;
		this.director = director;
		this.releaseDate = releaseDate;
		this.rating = rating;
		this.ticketprice = ticketprice;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getDirector() {
		return director;
	}

	public void setDirector(String director) {
		this.director = director;
	}

	public int getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(int releaseDate) {
		this.releaseDate = releaseDate;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public int getTicketprice() {
		return ticketprice;
	}

	public void setTicketprice(int ticketprice) {
		this.ticketprice = ticketprice;
	}

	@Override
	public String toString() {
		return "Movie [Id=" + Id + ", title=" + title + ", genre=" + genre + ", director=" + director + ", releaseDate="
				+ releaseDate + ", rating=" + rating + ", ticketprice=" + ticketprice + "]";
	}
	
	
	
}
